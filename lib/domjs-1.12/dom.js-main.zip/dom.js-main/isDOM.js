import isDOM from './utils/types/isDOM'

export default isDOM
