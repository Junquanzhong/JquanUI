export default isDeno;
/**
 * 检测当前运行环境是否为 Done 环境
 * ========================================================================
 * @method isDeno
 * @return {boolean}
 */
declare function isDeno(): boolean;
