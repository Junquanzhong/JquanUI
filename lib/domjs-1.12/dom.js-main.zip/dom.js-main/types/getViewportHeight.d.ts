export default getViewportHeight;
/**
 * ========================================================================
 * @method getViewportHeight
 * @return {Number}
 */
declare function getViewportHeight(): number;
