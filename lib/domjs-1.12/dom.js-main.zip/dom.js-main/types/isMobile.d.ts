export default isMobile;
/**
 * 检测当前设备是否为移动设备
 * ========================================================================
 * @method isMobile
 * @return {boolean}
 */
declare function isMobile(): boolean;
