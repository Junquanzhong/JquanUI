export default isFragment;
import isFragment from './utils/types/isFragment';
