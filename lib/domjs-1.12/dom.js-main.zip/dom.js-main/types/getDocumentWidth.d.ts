export default getDocumentWidth;
/**
 * ========================================================================
 * @method getDocumentWidth
 * @return {Number}
 */
declare function getDocumentWidth(): number;
