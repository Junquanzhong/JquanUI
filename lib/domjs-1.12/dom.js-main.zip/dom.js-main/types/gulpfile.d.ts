export const start: any;
declare const cleanDocs: any;
export const buildApi: any;
export const buildApiStyle: any;
export function buildApiPug(): any;
export const build: any;
export function lint(): any;
export function check(): any;
export { cleanDocs as clean };
