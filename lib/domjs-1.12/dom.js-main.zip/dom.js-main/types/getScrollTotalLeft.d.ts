export default getScrollTotalLeft;
declare function getScrollTotalLeft(el: any): any[];
