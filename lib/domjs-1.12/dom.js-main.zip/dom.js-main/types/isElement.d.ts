export default isElement;
import isElement from './utils/types/isElement';
