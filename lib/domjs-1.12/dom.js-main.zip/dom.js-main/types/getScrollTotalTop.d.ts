export default getScrollTotalTop;
declare function getScrollTotalTop(el: any): any[];
