export default getViewportWidth;
/**
 * ========================================================================
 * @method getViewportWidth
 * @return {Number}
 */
declare function getViewportWidth(): number;
