export default getDocumentHeight;
/**
 * 获取当前页面（滚动条）的高度
 * ========================================================================
 * @method getDocumentHeight
 * @return {Number}
 */
declare function getDocumentHeight(): number;
