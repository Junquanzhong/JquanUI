export default _getURLPattern;
declare function _getURLPattern(): RegExp;
