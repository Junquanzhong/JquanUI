export default isDOM;
import isDOM from './utils/types/isDOM';
