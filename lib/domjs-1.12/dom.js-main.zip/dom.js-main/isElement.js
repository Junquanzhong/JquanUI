import isElement from './utils/types/isElement'

export default isElement
