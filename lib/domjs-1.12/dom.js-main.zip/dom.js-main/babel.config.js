/**
 * babel.config.js - Babel 工程配置
 * =============================================================
 * Created By: Yaohaixiao
 * Update: 2023.9.4
 */
module.exports = {
  presets: [['@babel/preset-env']]
}
