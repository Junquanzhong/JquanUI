import isFragment from './utils/types/isFragment'

export default isFragment
