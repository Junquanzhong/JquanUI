#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const indexTypes = fs.readFileSync(path.join(root, 'dist/index.d.ts'), 'utf8');
const extractTypes = fs.readFileSync(path.join(root, 'dist/cli/jquan-extract.d.ts'), 'utf8');
const viteTypes = fs.readFileSync(path.join(root, 'dist/cli/jquan-vite-plugin.d.ts'), 'utf8');
const postcssTypes = fs.readFileSync(path.join(root, 'dist/cli/jquan-postcss-plugin.d.ts'), 'utf8');
const migrateTypes = fs.readFileSync(path.join(root, 'dist/cli/jquan-migrate.d.ts'), 'utf8');
const ssrTypes = fs.readFileSync(path.join(root, 'dist/ssr/jquan-ssr.d.ts'), 'utf8');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(/export const DEFAULT_EXTENSIONS/.test(indexTypes), 'root types missing DEFAULT_EXTENSIONS');
assert(/export const DEFAULT_CONFIG_FILES/.test(indexTypes), 'root types missing DEFAULT_CONFIG_FILES');

assert(!/vitePlugin/.test(extractTypes), 'extract subpath types must not expose vitePlugin');
assert(!/postcssPlugin/.test(extractTypes), 'extract subpath types must not expose postcssPlugin');
assert(!/\btokens\b/.test(extractTypes), 'extract subpath types must not expose tokens');
assert(/DEFAULT_EXTENSIONS/.test(extractTypes), 'extract subpath types missing DEFAULT_EXTENSIONS');
assert(/DEFAULT_CONFIG_FILES/.test(extractTypes), 'extract subpath types missing DEFAULT_CONFIG_FILES');
assert(/diagnoseProject/.test(extractTypes), 'extract subpath types missing diagnoseProject');
assert(/buildTemplatePages/.test(extractTypes), 'extract subpath types missing buildTemplatePages');
assert(/renderTemplateFile/.test(extractTypes), 'extract subpath types missing renderTemplateFile');
assert(/export function buildTemplatePages/.test(indexTypes), 'root types missing buildTemplatePages');
assert(/export function createNodeTemplateRuntime/.test(indexTypes), 'root types missing createNodeTemplateRuntime');
assert(/createTemplateBundle/.test(extractTypes), 'extract subpath types missing createTemplateBundle');
assert(/export function writeTemplateBundle/.test(indexTypes), 'root types missing writeTemplateBundle');
assert(/templateBundle\?: string \| false/.test(indexTypes), 'root VitePluginOptions missing templateBundle');
assert((indexTypes.match(/templateBundle\?: string \| false/g) || []).length >= 2, 'root PostCSSPluginOptions missing templateBundle');

assert(/export declare const VIRTUAL_ID/.test(viteTypes), 'vite types missing VIRTUAL_ID');
assert(/export declare const TEMPLATE_HMR_EVENT/.test(viteTypes), 'vite types missing TEMPLATE_HMR_EVENT');
assert(/export declare function jquanUIVitePlugin/.test(viteTypes), 'vite types missing named jquanUIVitePlugin');
assert(/export default jquanUIVitePlugin/.test(viteTypes), 'vite types missing default export');
assert(/templateHmr\?: boolean/.test(indexTypes), 'root VitePluginOptions missing templateHmr');
assert(/baselineCss: string/.test(indexTypes) && /utilityCss: string/.test(indexTypes), 'root extraction types missing split CSS fields');
assert(/split\?: boolean/.test(indexTypes), 'root extraction types missing split option');
assert(/baselineOutput\?: string \| false/.test(indexTypes), 'root plugin types missing baselineOutput');
assert(/utilitiesOutput\?: string \| false/.test(indexTypes), 'root plugin types missing utilitiesOutput');
assert(/prefetch\?\(classNames: Iterable<string> \| string, options\?: PrefetchOptions\): PrefetchResult/.test(indexTypes), 'root runtime types missing prefetch API');
assert(/export interface PrefetchOptions/.test(indexTypes) && /export interface PrefetchResult/.test(indexTypes), 'root types missing prefetch contracts');
assert(/export interface AdoptionOptions/.test(indexTypes) && /scan\?: boolean/.test(indexTypes) && /observe\?: boolean/.test(indexTypes), 'root types missing ShadowRoot adoption options');
assert(/getAdoptionStatus\?\(root\?: Document \| ShadowRoot\): AdoptionStatus/.test(indexTypes), 'root runtime types missing adoption status API');
assert(/createReactSSRAdapter/.test(indexTypes) && /export \* as ssr/.test(indexTypes), 'root types missing SSR adapter exports');
assert(/export interface SSRAdapter/.test(ssrTypes) && /createVueSSRAdapter/.test(ssrTypes) && /createSvelteSSRAdapter/.test(ssrTypes), 'SSR subpath types missing framework adapters');

assert(/export declare function buildExtraction/.test(postcssTypes), 'postcss types missing buildExtraction');
assert(/export declare function jquanUIPostCSSPlugin/.test(postcssTypes), 'postcss types missing named jquanUIPostCSSPlugin');
assert(/export default jquanUIPostCSSPlugin/.test(postcssTypes), 'postcss types missing default export');

assert(/export declare function auditCss\(/.test(migrateTypes), 'migrate types missing auditCss');
assert(/export declare function auditCssFiles\(/.test(migrateTypes), 'migrate types missing auditCssFiles');
assert(/export declare function auditClassFiles\(/.test(migrateTypes), 'migrate types missing auditClassFiles');
assert(/export declare function sortClassTokens\(/.test(migrateTypes), 'migrate types missing sortClassTokens');
assert(/export default migrate/.test(migrateTypes), 'migrate types missing default export');
assert(/export namespace migrate/.test(indexTypes), 'root types missing migrate namespace');
assert(/export function auditClassFiles\(/.test(indexTypes), 'root types missing migrate.auditClassFiles');
assert(/export function sortClassTokens\(/.test(indexTypes), 'root types missing migrate.sortClassTokens');
const browserGlobals = fs.readFileSync(path.join(root, 'dist/browser-globals.d.ts'), 'utf8');
assert(/export interface ComponentImportOptions/.test(indexTypes) && /componentLoader\?: ComponentImportOptions/.test(indexTypes), 'root types missing local component loader config');
assert(/import<T = Record<string, unknown>>\(name: string/.test(indexTypes) && /import<T = Record<string, unknown>>\(names: string\[\]/.test(indexTypes), 'root types missing component import overloads');
assert(/import type \{ JquanRuntimeApi \}/.test(browserGlobals) && /const JquanUI: JquanRuntimeApi/.test(browserGlobals), 'browser globals missing typed Core runtime');
assert(/interface IframeBridgeApi/.test(browserGlobals), 'browser globals missing iframe bridge API');
assert(/createParent\(options: IframeBridgeOptions/.test(browserGlobals), 'browser globals missing iframe bridge parent type');
assert(/request<T = unknown>/.test(browserGlobals), 'browser globals missing iframe bridge request type');
assert(/interface FaviconApi/.test(browserGlobals), 'browser globals missing favicon API');
const tableTypes = fs.readFileSync(path.join(root, 'dist/components/table.d.ts'), 'utf8');
assert(/interface TableOptions<Row extends object/.test(tableTypes) && /interface TableHandle<Row extends object/.test(tableTypes), 'Table types missing generic options/handle');
assert(/signal: AbortSignal \| null/.test(tableTypes) && /requestId: number/.test(tableTypes), 'Table types missing request metadata');
assert(/tableApi: TableApi/.test(browserGlobals) && /import\(name: 'table' \| 'table.js'/.test(indexTypes), 'Table globals/import are not typed');
assert(/status\(state: 'idle' \| 'loading' \| 'success'/.test(browserGlobals), 'browser globals missing favicon status type');
assert(/watch\(options: FaviconWatchOptions/.test(browserGlobals), 'browser globals missing favicon watch type');
const i18nTypes = fs.readFileSync(path.join(root, 'dist/components/i18n.d.ts'), 'utf8');
assert(/export interface I18nApi/.test(i18nTypes) && /registerMessages\(payload: Record<string, I18nMessages>/.test(i18nTypes), 'i18n types missing registration API');
assert(/nested\?: boolean/.test(i18nTypes) && /observe\(root\?: Document \| Element\): true/.test(i18nTypes), 'i18n types missing nested/observe contracts');
assert(/i18nApi: I18nApi/.test(browserGlobals) && /import\(name: 'i18n' \| 'i18n.js'/.test(indexTypes), 'i18n globals/import are not typed');

console.log('[JquanUI] types surface check ok');
