---
name: jquanui
description: 使用 JquanUI 构建、重构或审查 HTML、JavaScript、组件和前端界面。Use when an AI needs to create layouts, style semantic HTML, migrate CSS or inline styles to atomic classes, use JquanUI runtime/build-time extraction, configure themes, responsive/container/state variants, pseudo-elements, shortcuts, plugins, or JquanUI components. Enforce semantic atomic classes first and avoid custom CSS and arbitrary bracket values unless they are materially necessary.
---

# JquanUI AI 开发规范

Data layer reference: before using `jquanui/data`, read [DATA.md](./DATA.md). It defines the independent Data API, persistence, Schema migration, synchronization recovery, relations, and ecosystem reuse rules.

## 核心目标

使用语义化 HTML 和 JquanUI 原子类完成界面。默认只引入 Core，不创建页面级 CSS 文件，不写 `style=""`。

```html
<script>
  window.JQUAN_CONFIG = {
    theme: { extend: { colors: { primary: '#6366f1' } } }
  };
</script>
<script src="./js/JquanUI@core.min.js"></script>
```

配置必须位于 Core 之前。npm 项目可使用 `import 'jquanui/core'`。

## 强制优先级

按以下顺序解决样式需求，只有上一层不足时才进入下一层：

1. 使用正确的语义 HTML 元素和原生属性。
2. 使用现有语义原子类。
3. 使用响应式、状态、关系、属性或伪元素变体。
4. 使用最接近的设计令牌，不追求无视觉价值的像素级一致。
5. 仅对不可替代的值使用 `[...]` 任意值。
6. 对重复组合使用 `shortcuts`，对项目级令牌使用主题配置。
7. 对可复用新能力使用 `customUtilities` 或插件。
8. 只有原子系统确实无法表达时才创建 CSS。

不得因为“不记得类名”直接写 CSS。先查本 Skill、项目文档或用 `JquanUI.resolve()` 验证候选类。

## 语义近似规则

视觉差异不可感知时，使用最近的语义令牌：

- `font-size: 15px` -> `text-md`，不要写 `fs-[15px]`。
- `font-size: 16px` -> `text-md` 或 `text-base`。
- `margin: 15px` -> `m-4`（16px）。
- `gap: 7px` -> `gap-2`（8px）。
- `border-radius: 7px` -> `rounded-lg`（8px）。
- `width: 398px` 若不是固定规格 -> 使用响应式宽度、`max-w-*` 或布局约束。

可接受的近似范围：字号 1px、间距 2px、圆角 2px。品牌色、对齐基线、固定画布、协议尺寸和计算布局不得擅自近似，应配置主题令牌或使用任意值。

优先使用：

```text
text-xs 12px | text-sm 14px | text-md/text-base 16px | text-lg 18px
text-xl 20px | text-2xl 24px | text-3xl 30px | text-4xl 36px
p-1 4px | p-2 8px | p-3 12px | p-4 16px | p-6 24px | p-8 32px
gap-1 4px | gap-2 8px | gap-3 12px | gap-4 16px | gap-6 24px
```

## 任意值使用条件

仅在以下情况使用 `[...]`：

- `calc()`、`clamp()`、`minmax()`、复杂网格轨道。
- 设计稿中的固定设备/画布尺寸。
- CSS 变量、data URL、渐变、遮罩或裁剪路径。
- 项目未提供语义令牌且该值不能合理近似。
- 原生属性任意写法，例如 `[content:attr(data-label)]`。

任意值中的空格使用 `_`：

```html
<div class="grid grid-cols-[minmax(12rem,_18rem)_1fr]"></div>
<div class="w-[calc(100%-2rem)]"></div>
```

同一任意值出现两次以上时，升级为主题令牌、shortcut 或自定义工具，不要复制散落的魔法值。

## 能力地图

优先组合以下能力，不要重新实现：

- 布局：`block`、`flex`、`grid`、`container`、columns、float、position、inset、z-index。
- 尺寸与间距：width/height/min/max/size、margin、padding、gap、space、divide。
- 排版：font family/weight/style/size、line-height、tracking、word spacing、list、clamp、writing mode。
- 复合排版：`text-shadow-none` / `text-shadow-sm` / `text-shadow-md` / `text-shadow-lg`；复杂文字阴影使用 `text-shadow-[...]`，复合字体声明使用 `font-[...]`。
- 视觉：主题色与透明度、border、radius、outline、shadow、ring、gradient、background、mask、blend。
- 现代色彩：主题支持 `oklch()`、Display P3、`light-dark()`、`color-mix()` 及 `/透明度`；品牌色仍必须进入主题配置，不在 HTML 重复长颜色函数。
- 流体令牌：重复的响应式间距和字号配置到 `theme.extend.fluid`，使用 `py-fluid-section`、`max-w-fluid-frame`、`text-fluid-display`，不在模板散落 `clamp(...)`。
- 变换：translate、scale、rotate 2D/3D、skew、origin，自动合成 transform。
- 效果：opacity、filter、backdrop-filter、transition、animation。
- 现代滚动与性能：`scrollbar-gutter-*`、`overflow-anchor-*`、`content-visibility-*`、`contain-*`、`contain-intrinsic-size-*`。
- 滚动驱动动画：`animation-timeline-*`、`animation-range-*`、`scroll-timeline-*`、`view-timeline-*`、`timeline-scope-*`。
- 现代图形与排版：`image-rendering-*`、`text-size-adjust-*`、`shape-*`、`offset-*`、`decoration-skip-ink-*`。
- Anchor Positioning / View Transitions：`anchor-name-*`、`anchor-scope-*`、`position-anchor-*`、`position-area-*`、`position-try-*`、`position-try-order-*`、`position-visibility-*`、`view-transition-name-*`、`view-transition-class-*`、`view-transition-group-*`、`view-transition-types-*`。优先使用语义值，确有项目自定义锚点或区域时再使用任意值。
- 国际化排版：`text-autospace-*`、`text-spacing-trim-*`、`hyphenate-character-*`、`ruby-position-*`、`ruby-align-*`。
- 字体渲染：`font-kerning-*`、`font-optical-sizing-*`、`font-palette-*`、`font-synthesis-*`。
- SVG 与遮罩：`mask-mode-*`、`mask-type-*`、`mask-composite-*`、`mask-origin-*`、`paint-order-*`、`fill-rule-*`、`clip-rule-*`、`vector-effect-*`。
- 高级国际化排版：`font-variant-ligatures-*`、`font-variant-east-asian-*`、`text-rendering-*`、`text-orientation-*`、`white-space-collapse-*`。
- 表格与图像：`scrollbar-color-*`、`image-orientation-*`、`border-image-*`、`empty-cells-*`、`tab-size-*`。
- 打印分页：`break-*`、`page-break-*`、`orphans-*`、`widows-*`。新项目优先使用 `break-*`，仅需兼容旧打印引擎时使用 `page-break-*`。
- 逻辑布局与国际化换行：`is-*`、`bs-*`、`min-is-*`、`max-is-*`、`break-anywhere`、`break-auto-phrase`、`line-break-*`、`underline-position-*`、`resize-inline`、`resize-block`。
- SVG 高级表现：`shape-rendering-*`、`color-rendering-*`、`color-interpolation-*`、`text-anchor-*`、`dominant-baseline-*`、`baseline-shift-*`、`marker-*`。
- 字体回退与裁剪：`font-size-adjust-*`、`overflow-clip-margin-*`。仅在需要控制替代字体视觉比例或裁剪装饰溢出时使用。
- 逻辑滚动与东亚排版：`scroll-mi`、`scroll-mbs`、`scroll-pi`、`scroll-pbe`、`emphasis-*`。
- 逻辑边框与媒体：`border-bs-*`、`border-be-*`、`image-resolution-*`。
- 性能诊断：开发阶段使用低成本只读快照 `JquanUI.getMetrics()` 查看解析总数、规则数、队列状态、缓存命中率、最慢解析项、扫描/队列耗时和预算告警；需要未解析类、失败规则、插件状态或冲突明细时再使用 `JquanUI.debug()` / `JquanUI.diagnose()`。`getMetrics()` 不触发额外扫描；生产环境不要开启冲突追踪。
- 精确预取：路由、弹窗、异步区块或组件即将显示前，可调用 `JquanUI.prefetch(classes, { maxClasses, maxBytes, timeoutMs })` 预热明确类名。只传完整类名，不传 `hover:*`、`bg-*` 等无界模式；该 API 不扫描 DOM，并复用 Core 的解析、排序和缓存管线。
- 层叠顺序：Core 与构建提取共享 canonical utility order，`p-4 pt-2` 与 `pt-2 p-4` 的结果一致；大型项目可再配置 `cascadeLayers: true` 固定 `reset -> theme -> components -> utilities` 外层顺序。
- Shadow DOM：支持环境默认使用 Constructable Stylesheet；调用 `JquanUI.adopt(shadowRoot)` 会同步编译已有类并监听后续 class、状态属性和子节点变化，销毁时必须调用 `JquanUI.detach(shadowRoot)` 清理 observer 与插件行为。静态提取已覆盖全部类时可用 `{ scan: false }`，不可变根可用 `{ observe: false }`；通过 `JquanUI.getAdoptionStatus(shadowRoot)` 检查挂载状态。`adopt()` / `detach()` 可重复调用且不会移除第三方 sheet。可用 `constructableStylesheets: false` 强制 document 的 `<style>` fallback，但此模式不能挂载 ShadowRoot；不要创建第二套原子规则。
- 任意值安全：保留合法的 `calc()`、`env()`、`image-set()` 和 data URL；不要使用 `expression()`、`-moz-binding`、`behavior`、`javascript:` URL，也不要用未闭合的括号或方括号。
- 现代颜色：主题可使用 `oklch()`、`oklab()`、`lab()`、`lch()`、Display P3 和 8 位 HEX；alpha 组合会尽量保留颜色空间。重复颜色优先进入主题令牌，不要在 HTML 散落长颜色函数。
- 模板安全：不可信模板使用 `safe: true`；必要时配置 `safeResourceProtocols`、`safeDataImages: false` 或 `safeSanitizer`。内置净化始终先执行，后处理钩子不能替代它。
- 布局环境：responsive breakpoints、`max-*` / `min-*` 范围、dark/light、print、motion、contrast、LTR/RTL。
- 文档与设备环境：`lang-*`、`not-lang-*`、`pointer-*`、`hover-none`、`hover-hover`、`forced-colors`、`transparency-reduce`。
- 原生交互状态：`open:*`、`details-open:*`、`popover-open:*`、`modal:*`、`inert:*`、`user-valid:*`、`user-invalid:*`、`starting:*`。
- 移动安全区：`p-safe`、`px-safe`、`pt-safe`、`pb-safe`、`inset-safe`、`bottom-safe`，并支持 `pb-safe-4` 形式的语义附加间距。
- 容器查询：`@sm:`、`@[min-width:400px]:`、`@sm/sidebar:`、兼容的 `@sidebar/lg:`、`container-name-*`；重复阈值配置到 `theme.extend.containers`。
- 关系选择器：`group-*`、`peer-*`、`has-*`、`group-has-*`、`peer-has-*`、`*:`、`**:`。
- 任意变体：`[.scrolled_&]:`、`[&>img]:`、`supports-[...]`、`media-[...]`、`[@supports(...)]:`、`[@media(...)]:`。
- 属性状态：`data-*`、`aria-*`、`group-data-*`、`peer-data-*`、`group-aria-*`、`peer-aria-*`。
- 伪元素：`before:`、`after:`、`placeholder:`、`selection:`、`marker:`、`file:`、`first-line:`、`first-letter:`、`backdrop:`。
- 滚动条：`scrollbar:`、`scrollbar-track:`、`scrollbar-thumb:`、`scrollbar-corner:`。
- 扩展：shortcuts、plugins、custom utilities、semantic themes、safelist、debug/diagnose。
- 项目动效：在 `theme.extend.keyframes` 定义关键帧，在 `theme.extend.animation` 注册 `animate-*`，不为关键帧单独创建 CSS。
- 生产工具：CLI 静态提取、Vite、PostCSS、SSR critical CSS、W3C Design Tokens。
- 性能基准：修改扫描器、解析器、规则排序、缓存、Observer、Constructable Stylesheet 或构建提取后运行 `npm run benchmark:core`；发布候选运行 `npm run check:core-performance`。报告覆盖小页面、2500 节点、暖缓存、160 项变更、100 个 ShadowRoot 和构建提取，并写入 `reports/core-performance.json`。
- 迁移审计：面对存量 CSS，先运行 `jquan-migrate` 区分语义类、任意值候选和人工项；报告仅用于迁移决策，不机械删除复杂 CSS。

## 变体组合

从环境到状态再到工具排列，保持可读：

```html
<button class="px-4 py-2 bg-primary text-white hover:bg-primary/90 focus-visible:ring-2 disabled:opacity-50 md:px-6">
  保存
</button>

<div data-state="open" class="hidden data-[state=open]:block"></div>
<i class="transition-transform group-data-[state=open]:rotate-180"></i>
```

项目断点、语言和复杂祖先状态仍应写在 class 中：

```html
<div class="max-md:px-4 lang-en:tracking-wide [.scrolled_&]:bg-black/90"></div>
<div class="pointer-fine:hover:scale-105 supports-[backdrop-filter:blur(1px)]:backdrop-blur-md"></div>
```

任意选择器中 `_` 表示空格，`&` 表示当前元素。优先使用语义变体；只有不存在等价语义时才使用任意选择器或任意 at-rule。

多语言排版使用 `lang-*` 做最小差异修正，例如 `text-xl lang-en:text-lg`。`lang-en:` 基于原生 `:lang(en)`，会继承 `<html lang="en">`，同时匹配 `en-US` / `en-GB` 和局部 `lang` 子树。不要为每种语言复制整套 class，也不要用 JavaScript 切换字号类。

Dialog、Popover 和表单优先使用原生状态，不用 JavaScript 切换视觉类：

```html
<dialog class="opacity-100 starting:opacity-0 modal:grid"></dialog>
<div popover class="opacity-0 popover-open:opacity-100"></div>
<input class="user-invalid:border-red-500 user-valid:border-green-500">
```

全屏移动界面必须考虑安全区。直接使用 `pt-safe` / `pb-safe`；需要保留设计间距时使用 `pt-safe-4` / `pb-safe-2`，它们会把设备 inset 与语义间距相加。

使用变体组减少重复：

```html
<button class="hover:(bg-primary text-white shadow-lg) focus-visible:(ring-2 ring-primary/30)"></button>
```

## 伪元素规则

`before:` 和 `after:` 会自动生成空 `content`，装饰层不需要 CSS 文件：

```html
<div class="relative before:absolute before:inset-0 before:-z-10 before:rounded-lg before:bg-primary/10">
  内容
</div>

<span class="after:content-['NEW'] after:ml-2 after:text-primary">Inbox</span>
```

使用 `content-none` 禁用内容，使用 `content-[attr(data-label)]` 读取属性。父元素有定位需求时显式添加 `relative`；需要独立层叠上下文时添加 `isolate`。

## 主题与颜色

优先使用项目语义色：`primary`、`secondary`、`success`、`warning`、`danger` 或项目配置名。使用透明度后缀，例如 `bg-primary/10`、`border-primary/20`。

不得把品牌色重复写成 `bg-[#6366f1]`。应配置一次：

```js
window.JQUAN_CONFIG = {
  theme: {
    extend: {
      colors: {
        primary: '#6366f1',
        surface: '#ffffff'
      }
    }
  }
};
```

使用 `dark:` 处理深色模式。保持 class 优先、系统 media 兜底语义。

重复出现的跨视口尺度应配置为流体令牌，而不是反复写任意值：

```js
window.JQUAN_CONFIG = {
  theme: {
    extend: {
      fluid: {
        spacing: {
          section: ['3rem', '6vw', '6rem'],
          frame: { min: '18rem', preferred: '80vw', max: '72rem' }
        },
        fontSize: {
          display: { min: '2.25rem', preferred: '6vw', max: '4.5rem', lineHeight: '1.05' }
        }
      }
    }
  }
};
```

使用 `py-fluid-section`、`max-w-fluid-frame`、`text-fluid-display`。流体间距可用于间距、尺寸、布局和 Safe Area 附加间距。只有确实需要在最小值与最大值之间连续变化、并且会复用的设计尺度才应成为流体令牌；普通固定间距继续使用 `p-4`、`gap-6` 等基础令牌。

## 响应式与容器优先

先让 DOM 结构自然流动，再添加断点。移动端从单列开始：

```html
<section class="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3"></section>
```

组件内部优先使用容器查询，页面骨架使用 viewport 断点。不要用大量固定宽度修补响应式问题。

容器查询使用 `container-type-inline-size` 声明参照容器，组件后代使用 `@sm:`。命名容器推荐尺寸在前：`@sm/sidebar:grid-cols-2`；旧式 `@sidebar/sm:grid-cols-2` 同样兼容。`@[min-width:400px]:` 表示匿名任意条件，`@sidebar/[min-width:400px]:` 表示命名任意条件。多个 `@...:` 变体可以嵌套，保持书写顺序。重复的自定义阈值应配置为 `theme.extend.containers`，不要在多个模板复制任意值。

标准断点的上界使用 `max-{断点}:`，例如 `max-md:hidden`。项目可以在配置中增加自己的断点名，引擎会自动支持对应的正向与 `max-*` 变体；一次性精确边界可写 `max-[760px]:hidden`。不要把某个客户或页面的断点名称硬编码进通用组件，也不要为了单个最大宽度媒体查询新建 CSS 文件。

## 重复样式

重复的 5 个以上原子类组合应考虑 shortcut：

```js
window.JQUAN_CONFIG = {
  shortcuts: {
    'btn-primary': 'inline-flex items-center justify-center px-4 py-2 rounded-lg bg-primary text-white hover:bg-primary/90 focus-visible:ring-2'
  }
};
```

shortcut 表达视觉组合，语义和可访问属性仍写在 HTML 中。

## 存量 CSS 迁移

不要让 AI 一次性把整份 CSS 替换成中括号类。先运行：

```bash
npx jquan-migrate --input ./css --format markdown --output ./reports/jquan-migration.md --config ./jquan.config.cjs
```

按报告类别处理：

1. `semantic`：优先迁移，可接受 `15px -> text-md`、`15px -> p-4` 这类无感知近似。
2. `arbitrary`：先判断是否重复；重复两次以上应升级为主题令牌、流体令牌或 shortcut。
3. `manual`：保留并人工检查，尤其是复杂选择器、渐变、mask、shadow、transform 和 keyframes。

迁移后使用 `jquan-extract --doctor` 验证类名解析。只有完成视觉回归后才能删除对应 CSS；`jquan-migrate` 本身不会改写业务文件。

迁移工具的完整审计方式：

```bash
npx jquan-migrate --input ./css --source ./src --format markdown --output ./reports/jquan-migration.md --config ./tailwind.config.cjs
npx jquan-migrate --source ./src --max-order 0 --output ./reports/class-order.json
```

`--source` 会审计 HTML、JS/JSX/TS/TSX、Vue、Svelte、Astro、Markdown/MDX 中可静态发现的类字符串，给出 `original -> sorted`，只建议顺序，不直接改源码。顺序遵循布局 -> 定位 -> 尺寸 -> 间距 -> 排版 -> 颜色/边框 -> 效果 -> 状态/变体。`--min-semantic`、`--min-expressible`、`--max-manual`、`--max-order` 可作为 CI 阈值，失败统一返回状态码 `2`。

Tailwind 配置只作为令牌和断点上下文读取：支持 `theme.extend.colors`、`spacing`、`screens`、`borderRadius`、`fontSize`、`fontWeight`、`lineHeight`；插件、`corePlugins`、`variants` 只进入 `configWarnings`/`unsupportedTailwindTokens`，不会被执行，也不会假装已经迁移。报告中的 `before`/`after`、`reason` 和 `migrationSuggestions` 是人工迁移依据；复杂选择器、渐变、mask、shadow、transform、keyframes 继续人工处理。

项目专属动画应进入主题配置：

```js
window.JQUAN_CONFIG = {
  theme: {
    extend: {
      keyframes: {
        reveal: {
          from: { opacity: '0', transform: 'translateY(12px)' },
          to: { opacity: '1', transform: 'translateY(0)' }
        }
      },
      animation: { reveal: 'reveal 600ms ease both' }
    }
  }
};
```

HTML 使用 `animate-reveal motion-reduce:animate-none`。只有关键帧需要复杂选择器联动或不能用声明对象表达时才保留 CSS。

## JavaScript 与组件

动态状态优先修改标准属性或 `data-state`，让原子变体负责视觉：

```js
button.setAttribute('aria-expanded', String(open));
panel.dataset.state = open ? 'open' : 'closed';
```

不要在 JavaScript 中反复写 `element.style.*`。动态类必须是完整可扫描字符串；无法静态发现时加入 `safelist` 或调用 `JquanUI.addSafelist()`。

需要提前准备动态 UI 时，按用途选择 API：`JquanUI.compile(classes)` 用于已确定且需要立即生成的类；`JquanUI.prefetch(classes, options)` 用于有数量、CSS 字节和同步耗时预算的受控预热。默认预算是 `maxClasses: 100`、`maxBytes: 100000`、`timeoutMs: 50`。检查返回值的 `accepted`、`skipped`、`reason` 和 `truncated`；`skipped[].reason` 只会是 `max-classes`、`max-bytes` 或 `timeout`。已处理类不会重复插入或占用本次字节预算。

```js
const result = JquanUI.prefetch(
  ['grid', 'gap-4', 'hover:bg-primary/90', 'before:block'],
  { maxClasses: 40, maxBytes: 32000, timeoutMs: 16 }
);

if (result.truncated) console.table(result.skipped);
```

### JquanUI 全生态复用规范

JquanUI 采用“复用优先、原组件演进、独立能力解耦”的设计：

1. 先检查现有组件、API、适配器和工具链，优先直接调用公开能力。
2. 现有能力不足时，优先迭代原组件，保持旧 API 兼容并补齐通用能力。
3. 新组件只能调用扩展后的统一 API，不得复制 HTTP、存储、状态、分页、表格、校验或模板逻辑。
4. 只有职责边界或运行环境确实不同，才创建新的独立组件或适配器。
5. 扩展必须同步类型、文档、回归测试和聚合包。

### 文档配套闸门

凡是新增组件、功能、公开 API、配置项、变体或原子类，都必须同时完成配套文档；已有能力扩展时必须更新原有文档，不得只在源码或聊天记录中说明。文档至少包含用途、引入方式、最小示例、参数或类名、返回值/状态、依赖关系、限制和生态组合方式。提交前运行 `npm run check:docs`，并把新公开 API 加入文档覆盖清单。

### 文档也遵守组件优先

JquanUI 文档不是脱离生态的静态样稿，而是组件和原子引擎的真实使用场景。重构文档页面时，先复用已有 `template`、`codeBlock`、`tabs`、`toast`、`uiPreset` 和组件 API；现有能力不足时先扩展原组件，再考虑新增组件。公共页头、导航、搜索、页脚、代码示例和状态反馈应通过 Template 的 `include`、`layout`、`slot` 或现有组件集中维护，避免在多个 HTML 页面复制相同结构。

文档示例必须优先使用语义原子类，不能因为页面是文档就退回大段 CSS。示例中新增的类名、组件 API、配置和脚本必须能被当前 Core/Components 实际解析或执行；文档、`components.html`、README 和本 Skill 的同一能力说明应保持一致。完成文档组件化后运行 `npm run check:docs`、模板回归、组件回归和视觉结构检查。

### 组件文档模块规范

组件文档目录位于 `content/components/`，每个组件必须拥有同名的独立文档模块，并由 `content/components/index.js` 聚合。控制器 `js/components-docs.js` 只负责搜索、分类、公共渲染和演示生命周期，不再保存组件目录数据。每个模块至少提供 `id`、`title`、`chinese`、`category`、`kind`、`version`、`file`、`api`、`install`、`declarative`、`imperative`、`examples`、`attrs`、`methods`、`events` 和 `notes`。

`kind: 'ui'` 用于有可见 DOM 表面的组件，例如 Button、Tabs、Table、Modal；`kind: 'service'` 用于数据、网络、存储、模板和浏览器能力。文档分类必须帮助开发者先判断“放进页面的组件”还是“提供能力的服务”，不得把两者混成一个模糊类目。每个模块至少提供一个声明式示例和一个命令式/API 示例；详情页从 `examples` 渲染代码，不能在控制器中重复写同一段示例。

公共导航、组件页头、组件侧栏头、页脚和代码展示壳使用 `docs/templates/` 下的 Template 片段；组件模块只维护自己的用途、真实 API、示例和必要的演示初始化。新增或修改组件文档后运行 `npm run check:component-docs`，确认模块索引、分类、源码路径、API 方法和示例源没有分叉。

例如：Data 请求复用 `JquanUIComponents.httpApi`；HTTP 缺少通用能力时先扩展 `http.js`，不要在 Data 中重新实现 `fetch()`。Data 的页面结果交给 `paginationApi.updatePage()`；持久化优先复用 `storageApi`，只有 IndexedDB 等不同存储模型才新增适配器。

每次新增生态能力前，AI 必须说明已检查哪些现有能力、为何不能直接复用、是否应先迭代原组件，以及新 API 的归属。

需要交互组件时先检查 `jquanui/components`，不要重复实现现有 button、dialog、dropdown、tabs、tooltip、table、form、upload、router 等能力。

## 组件调用规范

JquanUI Core 只负责原子 CSS。组件位于 `dist/components`，通过 `window.JquanUIComponents` 暴露；不要把组件 API 当成 Core API，也不要在只加载 Core 时调用组件。

### 选择引入方式

按实际需求选择最小入口：

```html
<!-- 1. 只使用原子排版：默认首选 -->
<script src="./js/JquanUI@core.min.js"></script>

<!-- 2. 使用少量组件：Core + 单组件文件 -->
<script src="./js/JquanUI@core.min.js"></script>
<script src="./dist/components/overlayManager.js"></script>
<script src="./dist/components/dialog.js"></script>

<!-- 3. 使用多个组件：Core + Components 聚合包 -->
<script src="./js/JquanUI@core.min.js"></script>
<script src="./dist/components/JquanUI@components.js"></script>

<!-- 4. 使用完整运行时与预选组件集合时使用 Full -->
<script src="./dist/full/JquanUI@full.js"></script>
```

不要同时加载 Full、Core 和 Components 聚合包。不要同时加载 Components 聚合包和其中的单组件文件。npm 浏览器项目可使用 `import 'jquanui/core'`、`import 'jquanui/components/overlayManager'` 和 `import 'jquanui/components/dialog'`（手动安装顺序为 overlayManager → dialog）；使用全部组件时使用 `import 'jquanui/components'`。

### 本地组件按需导入

Core 已内置 `JquanUI.import()`。只加载 Core 后，优先用按名称导入代替手动追加组件 script；继续使用已有组件 API，不重复封装加载器：

```html
<script src="./dist/core/JquanUI@Core.js"></script>
<p id="status">等待加载</p>
<script type="module">
  const dom = await JquanUI.import('dom');
  dom.text('#status', '组件已加载');
  const [table, select] = await JquanUI.import(['table', 'select']);
</script>
```

也支持 `dom.js`；名字必须来自 `dist/components/components.manifest.json`，不传路径或 URL。默认下载本地组件、先加载依赖、再通过现有 `JquanUI.use()` 安装，返回同名 `*Api`；没有 API 时返回插件或 preset。重复与并发下载去重，已注册组件不重复执行文件；导入后不再手工 use 同一组件。

标准 `dist/core`、`dist/full` 与 `js/JquanUI@core.min.js` 入口自动推导组件目录。移动/重命名 Core 或使用其他资源布局时，在 Core 前配置 `JQUAN_CONFIG.componentLoader = { baseURL: './dist/components/' }`，或逐次传入第二参数。相对 `baseURL` 基于文档 URL / `<base>`；本地演示使用 HTTP 服务。

参数：`baseURL` 为目录；`timeout` 为正数毫秒，默认 15000；`nonce` 默认继承 Core script 的 CSP nonce；`install` 默认 true，false 只加载组件及依赖。批量调用返回与输入顺序相同的数组。TypeScript 可使用 `JquanUI.import<MyApi>('name')` 指定消费类型。

依赖来自插件 `requires`、使用到的 UI/Overlay Preset，以及 Table→Pagination、Crud→Modal/FormValidator/Table/HTTP、Storage→三个 driver 的现有组合约定。加载器只装配这些本地文件，不自动下载组件内部的第三方库。模板 loader、map 等组件仍遵守各自配置。

异常读取 `error.code`、`error.component`、`error.url`：未知名称 `COMPONENT_UNKNOWN`；错误参数 `COMPONENT_INVALID_OPTIONS`；下载失败 `COMPONENT_LOAD_FAILED`；超时 `COMPONENT_TIMEOUT`；未注册 `COMPONENT_NOT_REGISTERED`；安装失败 `COMPONENT_INSTALL_FAILED`；依赖环 `COMPONENT_DEPENDENCY_CYCLE`。失败下载可再次导入；已经加载的依赖保留，安装失败不回退已执行脚本。页面销毁仍调用具体句柄的 `destroy()`。

修改导入器后执行 `npm run check:component-import`、`npm run check:component-import:browser`、文档/类型检查，并同步 Core、压缩 Core 与 Full；导入器源在 `src/runtime/component-import.js`，组件目录由 `scripts/build-component-import.cjs` 从 manifest 生成。

### 标准安装顺序

组件脚本注册的是组件定义，必须在 Core 就绪后安装：

```html
<script src="./js/JquanUI@core.min.js"></script>
<script src="./dist/components/overlayManager.js"></script>
<script src="./dist/components/dialog.js"></script>
<script>
  JquanUI.use(JquanUIComponents.overlayManager);
  JquanUI.use(JquanUIComponents.dialog);
</script>
```

AI 必须遵守：

1. 先加载 Core，再加载组件脚本，再调用 `JquanUI.use()`。
2. 每个组件只安装一次；Core 会按组件名去重，但代码中仍不得重复调用。
3. 有依赖的组件先安装依赖，再安装主组件。
4. 声明式节点应在组件安装前已经存在；动态插入后可调用 `JquanUI.enhance(root)`。
5. 页面卸载、视图替换或测试结束时调用句柄/API 的 `destroy()`；不要遗留监听器和实例。
6. 不要猜测 API。先查 `js/components-docs.js` 中对应 `id`，再查 `dist/components/{name}.js` 的实际 `*Api` 导出。

依赖安装示例：

```js
JquanUI.use(JquanUIComponents.pagination);
JquanUI.use(JquanUIComponents.table);

JquanUI.use(JquanUIComponents.overlayManager);
JquanUI.use(JquanUIComponents.modal);
JquanUI.use(JquanUIComponents.formValidator);
JquanUI.use(JquanUIComponents.table);
JquanUI.use(JquanUIComponents.crud);
```

### 声明式优先，命令式补充

静态 HTML 优先写 `jq-*` / `data-jq-*` 属性，让插件自动增强：

```html
<div jq-tabs id="account-tabs">
  <nav jq-tab-list>
    <button type="button" jq-tab jq-target="#profile-panel">资料</button>
    <button type="button" jq-tab jq-target="#security-panel">安全</button>
  </nav>
  <div jq-tab-content>
    <section id="profile-panel" jq-tab-panel>资料内容</section>
    <section id="security-panel" jq-tab-panel>安全内容</section>
  </div>
</div>
```

需要数据、回调或程序控制时使用对应 API：

```js
JquanUI.use(JquanUIComponents.tabs);

const tabs = JquanUIComponents.tabsApi.mount('#account-tabs', {
  mode: 'fade'
});

tabs.goTo(1);
```

优先保存 `mount()` 返回的句柄，不要反复 mount 同一节点。更新时优先使用句柄的 `update()`、`patch()`、`setData()` 等现有方法，不要销毁 DOM 后重新实现组件。

### 高频组件范式

按钮通常只需声明式属性：

```html
<button type="button" jq-button data-variant="primary" data-size="sm">保存</button>
```

Dialog 是纯声明式组件，使用触发器和目标选择器；当前没有 `dialogApi`：

```html
<button type="button" jq-dialog-trigger jq-target="#confirm-dialog">打开</button>
<div jq-dialog id="confirm-dialog" aria-labelledby="confirm-title">
  <div jq-dialog-backdrop></div>
  <section jq-dialog-panel class="p-6">
    <h2 id="confirm-title">确认操作</h2>
    <button type="button" jq-dialog-close>取消</button>
  </section>
</div>
```

```js
await JquanUI.import('dialog'); // 自动装配 overlayManager
```

Dialog 1.1 已复用共享 OverlayManager：只关闭最上层、保留嵌套滚动锁、同步触发器 aria-expanded、恢复焦点及 overflow 原值/优先级。带 data-state="open" 的节点会立即加入堆栈；节点移除会释放，不访问 __jquan* 私有方法。手动引入必须先加载/安装 overlayManager，再安装 dialog。

自定义浮层也复用服务，先显示 DOM，再登记自己的句柄：

```js
const overlays = await JquanUI.import('overlayManager');
const element = document.querySelector('#custom-overlay');
element.hidden = false;
const layer = overlays.open({
  element, panel: element.querySelector('#custom-panel'),
  closeOnOutside: true,
  onClose() { element.hidden = true; }
});
// 视图卸载只释放自己的层：
layer.destroy();
```

默认 trapFocus、lockScroll、closeOnEscape 为 true，closeOnOutside 为 false；initialFocus 取 panel 内元素/选择器，returnFocus 默认打开前焦点，false 禁用恢复。open 同一活动 element 返回原句柄；top()/stack() 返回堆栈信息；close(reason?)/destroy() 幂等，state() 读取 closed/isTop。onClose 的内置 reason 包含 programmatic、escape、outside、destroy、detached。服务 destroy() 关闭所有共享层，仅用于整页清理；业务视图使用自己的 handle.destroy()。TypeScript 类型可从 jquanui/components/overlayManager 或根包导入。

当前服务不负责定位、portal、背景 inert 或跨 ShadowRoot/iframe 焦点；Modal 2.2、Drawer 1.2、Popover 1.5 已与 Dialog 共享堆栈；Select 尚未迁移。详细用法见 [OverlayManager 文档](../../content/components/overlayManager.js)。修改服务后运行 `npm run check:overlay:browser`（Core、压缩 Core、Full 的真实 Escape/Tab、焦点/锁恢复/销毁检查）、文档与类型检查，并重建各入口。

### Modal / Drawer 共享生命周期

优先 `await JquanUI.import('modal')` 或 `await JquanUI.import('drawer')`，自动安装 overlayManager → modal → drawer；手动脚本/npm 使用相同安装顺序并加载 overlayPreset。复用现有 form/image/confirm/promise/drawer surface，不创建第二套焦点、滚动锁、关闭监听。

```js
const modalApi = await JquanUI.import('modal');
const editor = modalApi.open({
  title: '记录详情',
  content: '<p class="text-sm">记录内容</p>',
  async beforeClose({ reason }) { return reason !== 'escape'; }
});
const accepted = await editor.close('saved'); // true 表示退出动画开始
// 视图卸载：editor.destroy();
```

close() 返回 Promise<boolean>，约 180ms 动画期间仍保留锁/焦点，state() 的 isClosing 为 true；销毁后 destroyed=true、element()=null。并发关闭共用同一次 beforeClose，返回 false/抛错会拒绝；busy 时阻止关闭。update/patch、destroy 使旧异步检查失效；closing 期间 update/patch 返回 null。用 update 修改 lockScroll/trapFocus/closeOnEscape/closeOnBackdropClick/zIndex；patch 只处理文档化的内容/外观字段。onDestroy 观察实际结束；closeAll 保留立即返回 true 的入口。

Modal 表单先按需导入 formValidator，复用校验服务和 Modal onSubmit；onSubmit 返回 false 保持打开，异步期间 busy。FormValidator 1.1 在手动 mount 后的自动 enhance 中保留原实例配置，旧节点清理不会删除新实例；Modal 重绘/销毁释放校验句柄，避免重复挂载或原生页面跳转。

Drawer id 可显式指定；同 id open 销毁旧实例，旧句柄不能影响替换实例。update/patch 累积配置并保持清理回调，返回底层 ModalHandle；state().id 为 Drawer id、modalId 为 Modal id。Drawer API target 可用当前句柄、id 或元素；使用自己的 destroy() 释放，避免整页 overlays.destroy() 影响其他视图。

OverlayManager 1.1 的 requestClose() 可由 onRequestClose 接管异步检查/动画；消费方最后调用 close() 才释放，close/destroy 直接释放并绕过请求检查。handle.update() 更新策略而不重开，focus() 只聚焦顶层，zIndex 为层的最小值；最后一个锁恢复 overflow-x/y、padding-right 值/优先级和原有标记，并补偿滚动条宽度。jquanui-overlay-change 文档事件同步通知层/策略变化。新类型从根包或 components/modal、components/drawer 导入；不要把 close 的 true 当作 DOM 已移除。

修改后运行 `npm run check:modal:browser`、`npm run check:overlay:browser`、文档与实际 TypeScript 消费检查，重建 Core 目录、压缩 Core、Components 和 Full。

### Popover 共享浮层

复用现有 `[jq-popover]` 根、`[jq-popover-trigger]` 和 `[jq-popover-panel]`，在 Modal/Drawer 内使用时把根放在其内容内。`await JquanUI.import('popover')` 自动安装 OverlayManager 与 overlayPreset；手动安装顺序为 preset → overlayManager → popover。

```js
const popoverApi = await JquanUI.import('popover');
const popover = popoverApi.mount('#details', {
  autoFocus: true, closeOnEscape: true,
  onClose(reason) { console.log(reason); }
});
popover?.open();
// 视图卸载：popover?.destroy();
```

Popover 1.5 保留 boolean 的 open/close/toggle/state，销毁后 state()/element() 为 null；API target 可用当前句柄、元素、id 或选择器。重复 mount 同节点保留首次配置；同 id 替换使旧句柄失效，旧 teardown 不删除新实例。closeAll 只关闭 Popover，不清理其他浮层。

click 默认自动聚焦、循环焦点；autoFocus=false 只跳过打开时聚焦，需同时 trapFocus=false 才取消焦点陷阱。hover 默认不聚焦、不循环、不返回焦点；mouseleave 关闭。Popover 不锁滚动，保留底层 Modal/Drawer 的锁。closeOnEscape/closeOnOutside 默认为 true；只响应最上层，禁用关闭仍屏蔽下层。触发器与根属于点击内部区域，外部关闭使用共享 click 并消费该点击。保留四方向、箭头、resize/scroll 定位，offset/padding 默认 10/8；服务未提供 portal。用法、classes、事件和限制见 [Popover 文档](../../content/components/popover.js)。

OverlayManager 1.2 的 outsideElements 扩展内部点击区域，不扩展焦点陷阱；autoFocus 控制初始聚焦，handle.update({ returnFocus: false }) 禁用返回旧触发器。Popover API/选项/句柄类型可从根包或 components/popover 导入。修改后运行 `npm run check:popover:browser`、已有 Modal/Overlay 回归、文档和真实 TypeScript 消费检查，并重建三个入口。

数据表格优先按需导入，自动安装 Pagination 和 UI Preset；手动引入时仍先安装 pagination，再安装 table：

```js
const tableApi = await JquanUI.import('table');
const table = await tableApi.mount('#records', {
  columns: [
    { key: 'name', title: '名称', sortable: true },
    { key: 'status', title: '状态' }
  ],
  data: rows
});

if (table) table.state();
```

Table 2.3 的远程加载器仍为 `remote: { enabled: true, load(payload, handle) }`。`payload` 增加 `requestId` 和 `signal`：新请求、`update({ data/remote })`、重挂载和销毁会使旧请求失效。只提交当前实例的最新结果；加载器即使忽略 signal，旧结果/旧错误也不会覆盖新状态。可用 AbortController 的环境会取消旧请求，不支持时 signal 为 null。

远程请求复用 HTTP，必须把 signal 传给它；不要在 Table 示例里重新封装 fetch：

```js
const [tableApi, http] = await JquanUI.import(['table', 'http']);
const table = await tableApi.mount('#records', {
  columns: [{ key: 'name', title: '名称', sortable: true }],
  pagination: { page: 1, pageSize: 20 },
  errorText: '加载失败，请重试',
  remote: {
    enabled: true,
    async load({ page, pageSize, signal }) {
      const response = await http.get('/api/records', {
        params: { page, pageSize }, signal
      });
      return response.data; // 服务端返回 { data: rows, total: number }
    }
  },
  onError(error, handle) {
    console.error(error.message, handle.state().requestId);
  }
});
```

`state()` 增加 loading、error、destroyed、requestId。当前请求失败会结束 loading、显示 errorText、调用 `onError(error, handle)`，并使命令式 `mount()` / `reload()` 拒绝；重试使用 `reload()`，调用方处理拒绝。过期请求失败不触发 onError。初始挂载失败后可通过 `tableApi.get(target)` 获取实例重试；初始化期间被销毁/替换时 mount 返回 null。

排序使用原生 button，支持 Enter / Space，列头同步 `aria-sort`，表格同步 `aria-busy`。重绘保留筛选焦点、选区与未提交草稿，程序化 `setFilter()` 使用传入新值。每次重绘先销毁旧 Pagination；`destroy()` 第一次返回 true，重复返回 false，旧句柄不能修改后来挂载的实例。

TypeScript 的 `JquanUI.import('table')` 返回 TableApi；`mount<Row>()`、options、remote payload、state 和句柄有独立类型，可从 `jquanui` / `jquanui/components/table` 导入。column.render 的兼容第三参数为 TableRenderState，selection / hiddenColumns 是 Set，不要当作公开 state() 的数组使用。Table 内部允许 render 返回受信任 HTML；外部数据仍由业务 render 适当转义。

修改这些能力后运行 `npm run check:table`、`npm run check:table:browser`、文档与类型消费检查，并重建 Components / Full。

表单校验使用原生 `form`、`label`、`name` 和约束属性，组件只补充规则与反馈：

```js
JquanUI.use(JquanUIComponents.formValidator);
const validator = JquanUIComponents.formValidatorApi.mount('#profile-form', {
  schema: { email: ['required', 'email'] }
});
const result = await validator.validate();
```

Toast、Msg、Copy 等命令式工具直接调用对应 API，不为它们重复创建状态系统：

```js
JquanUI.use(JquanUIComponents.toast);
JquanUIComponents.toastApi.success({ title: '保存成功' });
```

具体参数必须以当前组件文件为准，因为不同组件的 `mount/update/state/destroy` 签名可能不同。

### 基础服务组件调用规范

这些模块不是 Core 原子类，也不是页面级 CSS。使用前按“Core -> 组件脚本 -> use/install”加载；静态布局继续写 JquanUI 原子类，服务组件只处理运行时行为。

#### DOM 工具集

~~~html
<script src="./js/JquanUI@core.min.js"></script>
<script src="./dist/components/dom.js"></script>
<script>
  JquanUI.use(JquanUIComponents.dom);
  JquanDOM.ready(() => {
    const card = JquanDOM.create('article', {
      className: 'rounded-lg border border-slate-200 p-4 text-sm',
      text: '准备就绪'
    });
    JquanDOM.append('#root', card);
  });
</script>
~~~

JquanDOM / JquanUIComponents.domApi 支持 query/queryAll、create/build、append/prepend/before/after/remove/empty、html/text/val、attr/data/css、类名读写、节点关系、事件、表单序列化和三类原生观察器。目标参数可以是选择器、Element 或节点集合；on() 返回 handler，事件解绑时传给 off()；observer 需要调用 disconnect()。静态样式不要用 css() 逐项写回，优先原子类。

#### Permission 权限显示控制

~~~js
JquanUI.use(JquanUIComponents.permission);
const permissions = JquanUIComponents.permissionApi;
permissions.setPermissions(['component.read', 'component.write']);
permissions.setRoles(['admin']);
~~~

~~~html
<button type="button"
  data-permission="component.write"
  data-permission-deny="disable">
  保存
</button>
<div data-role-permission="admin">管理员区域</div>
~~~

has(values, mode)、hasRole(values, mode) 支持 some/every；can({ permission, permissionMode, role, roleMode }) 用于组合判断。默认拒绝会隐藏节点，data-permission-deny="disable" 会禁用控件。权限组件只控制前端显示，不替代服务端鉴权；权限变化后使用 refresh(root?)，不重新实现节点扫描。

#### Router 路由

~~~js
JquanUI.use(JquanUIComponents.router);
const router = JquanUIComponents.routerApi.create({
  root: '#router-view',
  mode: 'hash',
  routes: [
    { path: '/', title: '首页', component: '<h1>Home</h1>' },
    { path: '/users/:id', component: target => '<h1>User ' + target.params.id + '</h1>' }
  ],
  beforeEach: (to, from) => to.route?.meta?.public !== false
});
await router.push('/users/42');
~~~

句柄提供 current()、routes()、push(location)、replace(location)、resolve(location)、clearCache(path?)、destroy()。beforeEach 返回 false 取消导航，返回字符串执行重定向；afterEach 适合记录成功导航。component 可返回 HTML 字符串、Node，或 { content, destroy }。meta.permission/meta.role 会调用 Permission；keepAlive: true 配合 cacheLimit 使用。history 模式还需要服务器把未知路径回退到入口 HTML。

#### Store 状态仓库

~~~js
JquanUI.use(JquanUIComponents.storage);
JquanUI.use(JquanUIComponents.store);

const store = JquanUIComponents.storeApi.create({
  state: { filters: { status: 'all' }, page: 1 },
  persist: { key: 'filters', driver: 'local' }
});

const stop = store.watch(
  state => state.filters.status,
  status => console.log(status)
);
store.update('filters.status', 'active');
~~~

使用 getState() 读取完整快照，get(path, fallback?) 读取路径；set() 替换、patch() 深合并、update() 按路径更新。subscribe(listener, immediate?) 监听完整状态，watch(selector, listener, immediate?) 监听选择器，二者都返回取消函数。action(type, payload, meta) 记录动作，onAction() 监听动作；transaction() 适合一次性提交多项变更，reset() 恢复创建时的初始状态。persist 只能在 create() 中配置，并依赖 Storage 与对应 driver，不是 store 实例方法。视图销毁时取消订阅并调用 destroy()。

#### Toast 与 Msg

Toast 是卡片式操作反馈，使用 title/description；Msg 是更轻量的系统消息，使用 content。两者都通过 API 命令式调用：

~~~js
JquanUI.use(JquanUIComponents.toast);
const handle = JquanUIComponents.toastApi.success({
  title: '保存成功',
  description: '配置已更新'
});
handle.update({ description: '已同步' });
handle.close();
~~~

对应的 Msg 调用是 JquanUIComponents.msgApi.success({ content: '保存成功' })。两者都提供 show/info/success/warning/error/loading、update(id, options)、close(id)、closeAll(placement?)、config(options) 和 promise(promiseLike, states)；show() / loading() 返回 { id, close(), update() }。promise() 会把同一条 loading 通知更新为 success/error，并继续返回原 Promise 的结果或异常。不要为 Toast/Msg 重建一套状态管理；异步操作优先使用 promise()。

### 模板引擎

模板引擎属于 Components，不属于 Core：

```html
<script src="./js/JquanUI@core.min.js"></script>
<script src="./dist/components/template.js"></script>
<script>
  JquanUI.use(JquanUIComponents.template);
</script>
```

页面内公共模板使用 `include`：

```html
<template id="shared-card">
  <article class="rounded-lg border border-slate-200 p-4">
    <h3>{{ item.title }}</h3>
  </article>
</template>

<script type="text/jq-template" id="page-template">
  {% for item in items %}
    {% include 'shared-card' with { item: item } %}
  {% endfor %}
</script>

<main jq-template="page-template" data-jq-template-data='{"items":[]}'></main>
```

命令式模板使用：

```js
const templateApi = JquanUIComponents.templateApi;
const view = templateApi.mount('#view', {
  template: '<h2>{{ title }}</h2>',
  data: { title: 'JquanUI' },
  sanitize: true,
  safeExpressions: true
});

view.patch({ title: '更新后的标题' });
```

`{{ value }}` 默认转义，`{!! html !!}` 输出原始 HTML。模板或数据不完全可信时启用 `sanitize: true` 和 `safeExpressions: true`，并避免原始 HTML 输出。

统一安全场景优先使用 `safe: true`，不要只打开其中一项：它会同时启用安全表达式、HTML 净化、资源协议过滤和过滤器白名单。需要自定义过滤器时显式提供 `safeFilters`，并只加入无副作用、无 HTML 注入能力的过滤器。CLI 页面构建使用 `--safe`。

外部公共 HTML 模板已支持。必须先注册加载器，再安装 Template 插件：

```js
const templateApi = JquanUIComponents.templateApi;

templateApi.useLoader({
  name: 'JQFileLoader',
  base: './templates/',
  extensions: ['.html'],
  cache: {
    maxEntries: 64,
    ttl: 300000,
    version: 'site-v1'
  }
});

JquanUI.use(JquanUIComponents.template);
```

页面模板可以直接引用公共文件：

```html
<script type="text/jq-template" id="page-template">
  {% include 'header.html' %}
  <main>{{ title }}</main>
  {% include 'footer.html' %}
</script>

<div jq-template="page-template" data-jq-template-data='{"title":"首页"}'></div>
```

外部文件通过 `fetch()` 加载，页面必须运行在 HTTP 服务中，不能依赖 `file://`。命令式调用使用 `renderAsync()` / `mountAsync()`；同步 `render()` 不加载外部文件。可使用 `preload()`、`clearTemplateCache()`、`templateCacheSize()` 和 `inspectTemplate()` 管理缓存。外部缓存使用有上限的 LRU；`ttl` 单位是毫秒，`0` 表示不过期，部署新模板时顺延 `version`。编译缓存默认最多 500 项，特殊长生命周期页面可通过 `cacheLimit` 调整。默认禁止父级 `..` 路径、跨域 URL 和非 `.html/.htm` 文件；只有明确需求时才调整加载器选项。

调试多文件模板时使用 `await templateApi.dependencyGraph('page.html')` 获取递归依赖图；动态 include 表达式会进入 `dynamicDependencies`，不会被误请求为文件。捕获渲染错误时读取 `templateName`、`includeChain`、`position` 和 `snippet`，不要通过解析错误消息猜文件。`inspect(name)` 是 `inspectTemplate(name)` 的简写。

Vite 开发服务器会自动监听 `.html/.htm` 模板变化、清除匹配缓存并重渲染已挂载实例，生产构建不会注入 HMR 客户端。只有项目已有其他模板热更新方案时才配置 `templateHmr: false`。自定义开发服务器可以派发 `jquan:template:update` 事件，或直接调用 `templateApi.invalidate(name)` / `await templateApi.refresh(name)`。

生产静态站优先在构建期展开公共模板，避免浏览器运行时 `fetch()`：

```bash
npx jquan-extract --render-html ./pages --html-output ./dist --templates ./templates --data ./site.json
```

AI 使用该命令时必须把页面入口与公共模板目录分开：`pages` 只放需要输出的页面，`templates` 放 header、footer、layout 等片段。目录构建会保持页面相对路径；`site.json` 必须是对象。不得用 `..` 绕出模板根目录。需要在 Node 中接入时使用 `buildTemplatePages()`；只渲染一个页面字符串时使用 `renderTemplateFile()`，不要另写正则替换 include。

如果页面必须保留客户端模板渲染，则改用生产模板预打包，不要让每个 include 单独请求：

```bash
npx jquan-extract --bundle-templates ./templates --template-bundle-output ./dist/jquan.templates.js --templates ./templates
```

生成脚本可在 `template.js` 之前或之后加载；它写入 `window.JQUAN_TEMPLATES`，并在 API 已存在时调用 `registerTemplates()`。Vite 项目配置 `templateInput`、`templateRoot`、`templateBundle` 即可自动发射和注入；只有项目自行管理脚本标签时才设 `templateBundleInject: false`。静态内容优先用 `--render-html` 直接生成最终 HTML，确实需要浏览器数据驱动时才使用模板 bundle。

需要审计依赖或做精确缓存时，增加 `--template-bundle-report`，或在 Vite/PostCSS 中配置 `templateBundleReport`。SSR 代码优先使用语义明确的 `renderToString()` / `renderToStringAsync()`。

只有大模板且频繁更新、需要保留输入焦点或局部 DOM 状态时才设置 `patch: true`；普通页面不要启用，默认 `innerHTML` 更快。Patch 不是业务状态管理，仍应通过 `data`、句柄和标准属性更新状态。

### Iframe 通信组件

父页面与 iframe 子页面通信使用独立的 `iframeBridge`，不要在业务页面重复封装 `window.postMessage`。先加载 Core 和组件脚本，再安装组件：

```html
<script src="./dist/core/JquanUI@Core.js"></script>
<script src="./dist/components/iframeBridge.js"></script>
<script>
JquanUI.use(JquanUIComponents.iframeBridge);

const bridge = JquanUIComponents.iframeBridgeApi.createParent({
  iframe: '#report-frame',
  targetOrigin: window.location.origin,
  namespace: 'report'
});

bridge.on('ready', () => bridge.send('context', { locale: 'zh-CN' }));
bridge.on('request:health', () => ({ ok: true }));
const result = await bridge.request('load', { page: 1 });
bridge.destroy();
</script>
```

子页面使用 `createChild({ targetOrigin, namespace })`，请求处理器使用 `on('request:name', handler)`，普通消息使用 `on('name', handler)`。`ready()` 完成 handshake 后再发送依赖连接的请求。`targetOrigin` 必须是明确 origin；`targetOrigin: '*'` 只有显式设置 `allowAnyOrigin: true` 才会被接受。MessageChannel 默认启用，不能用时自动回退到 `postMessage`。销毁页面或 iframe 前调用 `destroy()`。

安全边界：通信协议只验证协议版本、命名空间、来源和消息源，不验证业务权限。不要把 payload 直接写入 `innerHTML`、执行为代码或当作登录授权；服务端权限仍需独立校验。

### Favicon 图标组件

浏览器标签页图标、未读数量和加载/成功/错误状态使用独立的 `favicon` 组件，不要在业务页面重复操作 `link[rel="icon"]` 或引入重复的 Favico 封装。它不依赖 Core，但推荐在 Core 后加载并安装：

```html
<script src="./dist/core/JquanUI@Core.js"></script>
<script src="./dist/components/favicon.js"></script>
<script>
JquanUI.use(JquanUIComponents.favicon);

const favicon = JquanUIComponents.faviconApi;
favicon.set('/assets/brand.svg');
favicon.badge(12, { color: '#dc2626' });
favicon.status('loading');
setTimeout(() => favicon.status('success'), 800);
</script>
```

公开能力：

- `set(source, options)` 设置 href、`{ svg }` 或 `{ canvas }` 图标，成为当前实例的 base icon。
- `badge(value, options)` 生成未读数量徽标；数字超过 999 显示 `999+`，空值通过 `clear()` 返回 base icon。
- `status('idle' | 'loading' | 'success' | 'error' | 'warning' | 'info', options)` 生成内置状态图标；loading 默认按帧更新，可用 `animate: false` 关闭。
- `watch({ light, dark })` 根据 `prefers-color-scheme` 选择图标，返回停止监听的函数。
- `clear()` 清除徽标/状态并恢复实例 base icon；`restore()` 恢复调用前原始 link；`destroy()` 停止计时器、主题监听并恢复原始图标。
- `create(options)` 创建独立句柄；多个句柄共享一个受管 favicon 节点，销毁非当前 owner 不会误删其他实例的图标。

输入规则：优先使用项目已有的静态 favicon URL；SVG 仅传入受信任的 `<svg>` 字符串，组件会拒绝 `script`、`foreignObject`、事件属性、脚本协议和 HTML 数据源；Canvas 必须能通过 `toDataURL('image/png')` 导出。组件会复用已有 `link[rel~="icon"]`，没有时才创建一个，不要为每次状态更新手动插入新的 link。

组件与 `notificationCenterPanel`、`msg` 或 `Data` 配合时，只传递未读数量或状态结果；不要把 favicon 当作通知队列、持久化层或权限提示的替代品。完整参数与开发者示例见 `components.html`。

### HTTP 请求客户端

HTTP 是纯 JavaScript 服务组件，不提供声明式 DOM。先加载 Core、HTTP 文件并安装组件，再通过 `JquanUIComponents.httpApi` 或独立实例调用：

```html
<script src="./dist/core/JquanUI@Core.js"></script>
<script src="./dist/components/http.js"></script>
<script>
  JquanUI.use(JquanUIComponents.http);
  const api = JquanUIComponents.httpApi.create({
    baseURL: '/api',
    timeout: 10000,
    retries: 2
  });
</script>
```

使用 `get/delete/head/options` 发送无请求体请求，使用 `post/put/patch` 发送 JSON、文本、Blob、FormData 或 URLSearchParams。普通对象默认序列化为 JSON，文件表单使用 `postForm()`，不要手动设置 multipart boundary。

```js
const response = await api.get('/contacts', {
  params: { status: 'active', page: 1 },
  responseType: 'json'
});
console.log(response.data, response.status, response.duration);

const created = await api.post('/contacts', { name: 'Ada' });
```

响应统一包含 `requestId`、`data`、`status`、`headers`、`config`、`url`、`ok`、`duration` 和 `raw`。非 2xx 默认抛出 `JquanHttpError`，读取 `error.code`、`error.response` 和 `error.config`，不要只依赖字符串消息。`timeout` 会产生 `ERR_TIMEOUT`；网络失败通常为 `ERR_NETWORK`；取消使用 `cancelSource()` 和 `isCancel()`：

```js
const source = api.cancelSource();
const pending = api.get('/report', { signal: source.signal });
source.cancel('离开报表页');
try {
  await pending;
} catch (error) {
  if (JquanUIComponents.httpApi.isCancel(error)) return;
  throw error;
}
```

拦截器 `use()` 返回移除函数；路由离开、组件销毁和测试结束时必须调用它。`setAuth({ token })` 或 `setAuth({ getToken })` 默认生成 Bearer Authorization 头，公共请求默认实例可直接调用 `httpApi.get()`。Data、Crud、Upload 等能力必须复用 HTTP，缺少通用能力时先扩展 HTTP 并补类型、文档和测试。

### i18n 国际化

i18n 同时支持声明式 DOM 和命令式 API。消息按 `locale -> namespace -> key` 组织，推荐显式初始化并关闭演示或测试中的持久化：

```js
const i18n = JquanUIComponents.i18nApi;
i18n.registerMessages({
  'zh-CN': { common: { greeting: '你好，{{name}}' } },
  'en-US': { common: { greeting: 'Hello, {{name}}' } }
});
await i18n.init({ locale: 'zh-CN', fallbackLocale: 'en', persist: false });
```

原生 HTML 使用 `data-i18n` 翻译文本，`data-i18n-placeholder`、`data-i18n-title`、`data-i18n-value` 翻译属性或控件值，`data-i18n-params` 传入 JSON 插值参数，`data-i18n-switcher` 提供语言切换按钮：

```html
<h1 data-i18n="common.greeting" data-i18n-params='{"name":"Ada"}'>欢迎</h1>
<input data-i18n-placeholder="common.search" aria-label="Search">
<button type="button" data-i18n-switcher="en-US">English</button>
```

默认插值会转义；只有内容完全可信时才使用 `data-i18n-html`。`setLocale()` 会翻译整个文档、更新 `<html lang>` 和 RTL 的 `dir`，也会触发 `change` 事件。`tn()` 处理复数，`td()` 处理日期，`tc()` 处理货币或使用 `formatValue()` 直接调用 Intl。大型页面可调用 `translate(root)` 只更新局部节点；使用 `observe(root)` 监听动态节点后必须在销毁时 `disconnect()`。

语言包可通过 `localesPath` 或 `loader(locale, options)` 异步加载，开启 `autoLoad` 后 `init()` 和 `setLocale()` 会等待资源。默认检测顺序为 URL、存储、`<html lang>`、浏览器语言、默认语言；SSR 或首屏要求稳定时显式传入 locale，避免仅依赖 navigator。

### Storage 存储生态

Storage 是统一门面，不是新的介质。使用它前必须加载并安装 `localStorage`、`sessionStorage`、`cookie` 三个 driver，再安装 `storage`：

```js
JquanUI.use(JquanUIComponents.localStorage);
JquanUI.use(JquanUIComponents.sessionStorage);
JquanUI.use(JquanUIComponents.cookie);
JquanUI.use(JquanUIComponents.storage);

const storage = JquanUIComponents.storageApi;
storage.config({ namespace: 'crm', defaultDriver: 'local' });
storage.set('filters', { status: 'active' }, { ttl: 86400000 });
const filters = storage.get('filters', {});
```

统一 API 包括 `get`、`set`、`remove`、`has`、`touch`、`keys`、`entries`、`getMany`、`setMany`、`clear` 和 `purgeExpired`。单次操作通过 `{ driver: 'session' }` 覆盖默认 driver；`storage.driver('cookie')`、`storage.local()`、`storage.session()` 可读取原始 driver。对象和数组自动序列化，TTL 单位为毫秒；Cookie 自身的 `maxAge` 单位是秒。

支持事件的 driver 的 `on(key, callback)` 返回取消函数。localStorage 会转发当前页写入和其他标签页的 `storage` 事件；sessionStorage 只在当前标签页有效。默认 `clear()` 只清理当前 namespace，跨项目或测试环境务必设置独立 namespace。存储不可用时先检查 `isAvailable()`，不要把 localStorage、sessionStorage 或可脚本读取的 Cookie 当作密钥保管区。

### 组件索引

优先复用下列已有组件，不要重新实现同类能力：

- 基础交互：`button`、`accordion`、`tabs`、`dialog`、`modal`、`drawer`、`dropdown`、`popover`、`tooltip`、`select`。
- 表单与输入：`formValidator`、`schemaForm`、`tagInput`、`upload`、`relationPicker`、`mediaPicker`、`filterBuilder`。
- 数据与内容：`table`、`pagination`、`tree`、`infiniteScroll`、`mdViewer`、`codeBlock`、`carousel`、`video`、`audio`、`map`。
- 反馈与输出：`toast`、`msg`、`notificationCenterPanel`、`copy`、`export`、`print`、`watermark`、`favicon`。
- 应用能力：`router`、`appShell`、`http`、`store`、`storage`、`localStorage`、`sessionStorage`、`cookie`、`permission`、`i18n`、`template`、`dom`、`overlayManager`。
- 组合能力：`crud`、`kanbanBoard`、`approvalFlow`、`auditTimeline`、`commentThread`、`revisionCompare`、`taskInbox`、`workspaceSwitcher` 等。

组件索引只用于发现能力。实际调用前必须核对当前组件文档和源码，尤其是组合组件的依赖、异步返回值和销毁方法。

### 组件样式规则

- 组件外层布局仍使用 Core 原子类，不把业务页面布局塞进组件配置。
- 优先通过组件提供的 `classes`、variant、size 或状态属性定制；没有公开入口时再评估扩展。
- 不修改组件内部生成 DOM 的私有 class，不依赖未文档化结构写深层 CSS。
- 动态状态优先使用 `aria-*`、`data-state` 和原生属性，配合 Core 变体。
- 组件不存在时，先判断能否用原生 HTML + Core 原子类完成；只有重复且通用的交互才新增组件。

表单优先使用 `field-sizing-content` / `field-sizing-fixed`、`color-scheme-light` / `color-scheme-dark` 和 `caret-*`，不要为原生控件尺寸、深浅色控件或光标颜色新增 CSS。

现代排版优先使用 `text-wrap-stable`、`text-box-trim-*`、`text-box-edge-*`、`interpolate-size-*` 和 `box-decoration-*`，只有引擎没有对应语义映射时才写 CSS。

## 允许独立 CSS 的边界

仅允许以下情况，并在代码中说明原因：

- 项目专属复杂 `@keyframes`，且内置 animation 无法表达。
- 第三方库只能通过深层选择器覆盖。
- 浏览器特性无法由当前变体或任意属性表达。
- 大段打印排版、富文本内容策略或全局文档样式。
- 性能验证证明单一静态规则优于大量动态原子规则。

即使需要 CSS，也先把布局、间距、颜色和响应式保留为原子类，只把不可表达部分放入 CSS。

## 构建与生产

- 小型静态页或动态原型：直接加载 Core。
- 多页静态站生产构建：使用 `jquan-extract --render-html` 预展开 include/layout。
- 客户端模板生产构建：使用 `--bundle-templates` 或 Vite `templateBundle` 预打包，避免运行时逐文件请求。
- PostCSS 项目也可配置 `templateInput`、`templateRoot`、`templateBundle` 生成同一模板 bundle；该能力默认关闭。
- 模板运行时回归使用 `npm run check:template-runtime`，覆盖语法、循环、缓存、异步 include、安全模式和 DOM mount 生命周期；新增模板能力后必须运行它。
- Vite/PostCSS 项目：使用 `jquanui/vite` 或 `jquanui/postcss` 构建时提取。
- SSR：单一 HTML 字符串使用 `renderCriticalCss` / `injectCriticalCss` 注入首屏 CSS；React/Vue/Svelte/Next/Nuxt 接入使用 `jquanui/ssr`，它只复用现有提取器，不安装或模拟框架运行时。React 用 `createReactSSRAdapter({ renderToString })`，Vue 用异步 `createVueSSRAdapter({ renderToString })`，Svelte 用 `createSvelteSSRAdapter({ render })`，并以 `{ document: true }` 保留 `{ html, head, css }`；Next/Nuxt 在最终 HTML 响应处调用 `createNextSSRAdapter().inject(renderedHtml)` / `createNuxtSSRAdapter().inject(renderedHtml)`。应用有自己的 HTML 壳时，在适配器配置中提供 `document(rendered, options)`；它会同时被 `{ document: true }` 和 `adapter.createDocument()` 复用。CSP nonce、id、theme/config、safelist 统一放进 `critical` 配置，禁止另写第二套服务端 CSS 生成器。
- 动态服务端类名：配置 `safelist`。
- 发布前运行 `npm run verify`。
- Core 性能相关改动还必须运行 `npm run check:core-performance`。只比较同一机器、浏览器和样本数的 median；不得把单机绝对耗时、一次快样本或未经验证的倍数写成普遍性能承诺。无标准路径 Chromium 时通过 `JQUAN_BROWSER` 指定 Edge、Chrome 或 Chromium。

## 执行工作流

1. 阅读现有 HTML、组件约定和主题配置。
2. 选择语义元素，补齐 label、button type、aria、alt 等属性。
3. 用原子类完成布局、排版、颜色和状态。
4. 将任意值逐项替换为最近的语义令牌；保留确有意义的精确值。
5. 将重复组合提升为 shortcut 或项目令牌。
6. 检查 `before/after`、dark、hover、focus-visible、disabled 和动态状态。
7. 在至少 390px 移动端和 1280px 桌面验证无溢出、遮挡和孤字换行。
8. 检查控制台，并使用 `JquanUI.debug()` 查看未解析类和失败规则。
9. 对构建项目运行提取或项目验证命令。

## 文档页面标准

原子类和平台能力文档统一对标 `content/font.js` 的“说明 + 演示 + 交互”结构，不能只堆砌类名表。每个高频能力至少包含：

1. **用途说明**：说明解决什么真实排版或交互问题，以及什么时候应该使用它。
2. **最小示例**：展示推荐的语义类组合，并明确配置、依赖和浏览器前提。
3. **可视演示**：让开发者直接看到类名产生的布局、颜色、状态或排版结果。
4. **可操作交互**：能通过按钮、原生控件、拖动或输入改变状态；交互必须调用真实引擎能力，不得伪造结果。
5. **实时反馈**：展示当前状态、实际 class/API 调用或生成结果，便于定位问题。
6. **可复制代码**：代码必须与演示保持同步，使用当前 Core、组件 API 和版本，不得使用过期类名。

文档演示优先使用原生 HTML 属性、Core 原子变体和已有组件；不要为演示额外创建页面 CSS。交互销毁逻辑必须放在页面模块的 `unmount()` 或组件句柄中，动态 DOM 更新后重新调用 `JquanUI.enhance()`。新增 API、原子类或组件时，同时更新对应 `content/*.js`、`components.html` 或 CSS 文档导航、README/Skill、回归检查和 CHANGELOG。验收至少包括桌面视口、390px 移动视口、控制台无错误、示例状态可复现和代码复制结果一致。

## 输出要求

- 输出或修改实际可运行代码，不只描述方案。
- 默认不创建 CSS 文件，不输出 inline style。
- 说明保留任意值或 CSS 的具体原因。
- 不虚构类名；不确定时通过 `JquanUI.resolve('candidate')` 或项目测试确认。
- 保持类名顺序稳定：布局 -> 尺寸 -> 间距 -> 排版 -> 颜色/边框 -> 效果 -> 状态 -> 响应式。
